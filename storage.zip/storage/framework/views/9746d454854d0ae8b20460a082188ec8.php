

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto px-4 py-8 space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-semibold text-slate-900">Host Dashboard</h1>
            <p class="text-sm text-slate-500">Kelola station Anda</p>
        </div>
        <a href="/host/create" class="inline-flex items-center px-4 py-2 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700">Tambah Station</a>
    </div>

    <?php if(session('success')): ?>
        <div class="rounded-lg border border-emerald-200 bg-emerald-50 text-emerald-800 px-4 py-3 text-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($stations->isEmpty()): ?>
        <div class="bg-white border border-slate-200 rounded-xl p-8 text-center text-slate-600">
            Belum ada station. Tambahkan station pertama Anda.
        </div>
    <?php else: ?>
        <div class="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
            <table class="w-full text-sm text-left">
                <thead class="bg-slate-50 text-slate-600 uppercase text-xs">
                    <tr>
                        <th class="px-4 py-3">Nama</th>
                        <th class="px-4 py-3">Alamat</th>
                        <th class="px-4 py-3">Harga/Jam</th>
                        <th class="px-4 py-3">Slot Available</th>
                        <th class="px-4 py-3">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__currentLoopData = $stations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-slate-50">
                            <td class="px-4 py-3 font-medium text-slate-900"><?php echo e($station->name); ?></td>
                            <td class="px-4 py-3 text-slate-700 text-sm"><?php echo e($station->address ?? '-'); ?></td>
                            <td class="px-4 py-3 text-slate-700">Rp <?php echo e(number_format($station->price_per_kwh, 0, ',', '.')); ?></td>
                            <td class="px-4 py-3">
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-700">
                                    <?php echo e($station->availableSlots()); ?> / <?php echo e($station->chargingSlots()->count()); ?>

                                </span>
                            </td>
                            <td class="px-4 py-3">
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold <?php echo e($station->is_active ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-700'); ?>">
                                    <?php echo e($station->is_active ? '✓ Active' : '○ Inactive'); ?>

                                </span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\voltshare\resources\views/host/index.blade.php ENDPATH**/ ?>