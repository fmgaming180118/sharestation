<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VoltShare | Login</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="min-h-screen bg-slate-100 flex items-center justify-center">
    <div class="w-full max-w-md bg-white shadow-lg rounded-xl p-8 space-y-6">
        <div class="text-center">
            <div class="text-3xl font-semibold text-slate-900">VoltShare</div>
            <p class="text-sm text-slate-500 mt-1">Charge smarter with Google</p>
        </div>

        <a href="/auth/google" class="flex items-center justify-center gap-3 w-full border border-slate-200 rounded-lg py-3 px-4 bg-white text-slate-800 font-medium hover:bg-slate-50 transition">
            <svg class="w-5 h-5" viewBox="0 0 533.5 544.3" aria-hidden="true">
                <path fill="#4285f4" d="M533.5 278.4c0-17.4-1.6-34-4.6-50.2H272v95.1h146.9c-6.3 34-25 62.8-53.2 82.1v68h86.1c50.4-46.5 81.7-115.2 81.7-195z"/>
                <path fill="#34a853" d="M272 544.3c71.6 0 131.7-23.7 175.6-64.8l-86.1-68c-23.9 16.1-54.4 25.5-89.5 25.5-68.8 0-127-46.4-147.8-108.9h-89v68.8c43.6 86.5 133.4 147.4 236.8 147.4z"/>
                <path fill="#fbbc04" d="M124.2 328.1c-10.8-31.7-10.8-65.7 0-97.4v-68.8h-89c-38.3 76.5-38.3 166.6 0 243.1z"/>
                <path fill="#ea4335" d="M272 107.7c37.4-.6 73.2 13.6 100.6 39.8l74.9-74.9C403.2 24.5 339.4-1 272 0 168.6 0 78.8 60.9 35.2 147.4l89 68.8C145 154.1 203.2 107.7 272 107.7z"/>
            </svg>
            <span class="text-base">Sign in with Google</span>
        </a>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\voltshare\resources\views/auth/login.blade.php ENDPATH**/ ?>