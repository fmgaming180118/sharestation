<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VoltShare | Home</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        .pulse-ring {
            position: relative;
        }
        .pulse-ring::after {
            content: '';
            position: absolute;
            inset: -10px;
            border-radius: 9999px;
            border: 3px solid rgba(59, 130, 246, 0.35);
            animation: pulse 1.6s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(0.95); opacity: 0.8; }
            70% { transform: scale(1.25); opacity: 0; }
            100% { transform: scale(1.25); opacity: 0; }
        }
    </style>
</head>
<body class="min-h-screen bg-slate-50 text-slate-900">
    <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="max-w-6xl mx-auto px-4 py-6 space-y-4">
        <div id="map" class="w-full h-[70vh] rounded-xl border border-slate-200 shadow-sm"></div>
    </main>

    <?php if(!empty($activeBooking)): ?>
        <?php if (isset($component)) { $__componentOriginal549958b93867689afa76c88ea32a0582 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal549958b93867689afa76c88ea32a0582 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.charging-circle','data' => ['booking' => $activeBooking]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('charging-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['booking' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activeBooking)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal549958b93867689afa76c88ea32a0582)): ?>
<?php $attributes = $__attributesOriginal549958b93867689afa76c88ea32a0582; ?>
<?php unset($__attributesOriginal549958b93867689afa76c88ea32a0582); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal549958b93867689afa76c88ea32a0582)): ?>
<?php $component = $__componentOriginal549958b93867689afa76c88ea32a0582; ?>
<?php unset($__componentOriginal549958b93867689afa76c88ea32a0582); ?>
<?php endif; ?>
    <?php endif; ?>

    <script>
        const stations = <?php echo json_encode($stations ?? [], 15, 512) ?>;
        const activeBooking = <?php echo json_encode($activeBooking ?? null, 15, 512) ?>;

        function initMap() {
            const defaultCenter = stations.length ? { lat: parseFloat(stations[0].latitude), lng: parseFloat(stations[0].longitude) } : { lat: -6.175, lng: 106.827 };
            const map = new google.maps.Map(document.getElementById('map'), {
                center: defaultCenter,
                zoom: 14,
                styles: [
                    { featureType: 'poi', stylers: [{ visibility: 'off' }] },
                    { featureType: 'transit', stylers: [{ visibility: 'off' }] }
                ]
            });

            stations.forEach((s) => {
                const position = { lat: parseFloat(s.latitude), lng: parseFloat(s.longitude) };
                const marker = new google.maps.Marker({
                    position,
                    map,
                    title: s.name,
                });
                const info = new google.maps.InfoWindow({
                    content: `<div style="min-width:180px;">
                        <div style="font-weight:600; color:#0f172a;">${s.name}</div>
                        <div style="color:#475569; font-size:13px;">${s.address ?? ''}</div>
                        <div style="margin-top:6px; font-size:13px; color:#1d4ed8;">Rp ${Number(s.price_per_kwh || 0).toLocaleString()} / kWh</div>
                    </div>`
                });
                marker.addListener('click', () => info.open({ anchor: marker, map }));
            });
        }

        function startCountdown() {
            if (!activeBooking || !activeBooking.end_at) return;
            const end = new Date(activeBooking.end_at).getTime();
            const el = document.getElementById('countdown');
            const tick = () => {
                const diff = end - Date.now();
                if (diff <= 0) {
                    el.textContent = '00:00';
                    return;
                }
                const mins = Math.floor(diff / 60000);
                const secs = Math.floor((diff % 60000) / 1000);
                el.textContent = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
                requestAnimationFrame(tick);
            };
            tick();
        }

        window.initMap = initMap;
        document.addEventListener('DOMContentLoaded', startCountdown);
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(config('services.google.maps_key')); ?>&callback=initMap" async defer></script>
</body>
</html>
<?php /**PATH C:\laragon\www\voltshare\resources\views/home.blade.php ENDPATH**/ ?>