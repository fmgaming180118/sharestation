

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto px-4 py-8 space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-semibold text-slate-900">My Bookings</h1>
            <p class="text-sm text-slate-500">Riwayat pengecasan Anda</p>
        </div>
        <a href="/" class="text-sm text-blue-600 hover:text-blue-700">Cari Station</a>
    </div>

    <?php if($bookings->isEmpty()): ?>
        <div class="bg-white border border-slate-200 rounded-xl p-8 text-center space-y-4">
            <div class="text-lg font-semibold text-slate-800">Belum ada riwayat pengecasan</div>
            <p class="text-slate-500">Mulai dengan memilih station terdekat untuk pengecasan.</p>
            <a href="/" class="inline-flex items-center justify-center px-4 py-2 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700">Cari Station</a>
        </div>
    <?php else: ?>
        <div class="space-y-4">
            <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $start = $booking->start_at;
                    $end = $booking->end_at;
                    $durationMinutes = ($start && $end) ? $start->diffInMinutes($end) : null;
                    $durationText = $durationMinutes ? sprintf('%02d jam %02d menit', intdiv($durationMinutes, 60), $durationMinutes % 60) : '-';
                    $startText = $start ? $start->format('d M Y, H:i') : '-';
                    $amountText = 'Rp ' . number_format($booking->amount ?? 0, 0, ',', '.');
                ?>
                <div class="bg-white border border-slate-200 rounded-xl p-5 flex flex-col gap-3 shadow-sm">
                    <div class="flex items-center justify-between">
                        <div class="text-lg font-semibold text-slate-900"><?php echo e($booking->station->name ?? 'Unknown Station'); ?></div>
                        <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $booking->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($booking->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm text-slate-600">
                        <div>
                            <div class="text-slate-500">Waktu</div>
                            <div class="font-medium text-slate-900"><?php echo e($startText); ?></div>
                        </div>
                        <div>
                            <div class="text-slate-500">Durasi</div>
                            <div class="font-medium text-slate-900"><?php echo e($durationText); ?></div>
                        </div>
                        <div>
                            <div class="text-slate-500">Total</div>
                            <div class="font-medium text-slate-900"><?php echo e($amountText); ?></div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\voltshare\resources\views/bookings/index.blade.php ENDPATH**/ ?>