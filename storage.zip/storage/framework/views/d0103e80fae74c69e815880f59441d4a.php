<!-- Navbar Component -->
<header class="bg-white border-b border-slate-200 sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 py-4">
        <div class="flex items-center justify-between">
            <!-- Logo -->
            <a href="/" class="text-xl font-semibold text-blue-600">⚡ VoltShare</a>

            <!-- Navigation Menu -->
            <?php if(auth()->guard()->check()): ?>
                <nav class="hidden md:flex items-center gap-6 text-sm">
                    <?php ($user = Auth::user()); ?>
                    
                    <!-- Guest Menu -->
                    <?php if(!$user->is_host): ?>
                        <a href="/" class="text-slate-600 hover:text-slate-900">Cari Station</a>
                        <a href="/my-bookings" class="text-slate-600 hover:text-slate-900">Booking Saya</a>
                    <?php else: ?>
                        <!-- Host Menu -->
                        <a href="/host/dashboard" class="text-slate-600 hover:text-slate-900">Dashboard</a>
                        <a href="/host/create" class="text-slate-600 hover:text-slate-900">Tambah Station</a>
                    <?php endif; ?>
                </nav>
            <?php endif; ?>

            <!-- Right Section: Avatar & Menu -->
            <div class="flex items-center gap-4">
                <?php if(auth()->guard()->check()): ?>
                    <?php ($user = Auth::user()); ?>
                    <div class="flex items-center gap-3">
                        <?php if($user->avatar): ?>
                            <img src="<?php echo e($user->avatar); ?>" alt="Avatar" class="w-10 h-10 rounded-full border border-slate-200 object-cover" referrerpolicy="no-referrer">
                        <?php else: ?>
                            <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-sm font-semibold text-blue-700">
                                <?php echo e(strtoupper(substr($user->name ?? 'U', 0, 1))); ?>

                            </div>
                        <?php endif; ?>
                        
                        <!-- Dropdown Menu -->
                        <div class="relative group">
                            <button class="text-sm text-slate-700 font-medium hover:text-slate-900 flex items-center gap-1">
                                <?php echo e($user->name); ?>

                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"></path></svg>
                            </button>
                            
                            <!-- Dropdown Items -->
                            <div class="absolute right-0 mt-0 w-48 bg-white border border-slate-200 rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                                <div class="px-4 py-3 border-b border-slate-100">
                                    <p class="text-xs text-slate-500">Akun</p>
                                    <p class="text-sm font-semibold text-slate-900"><?php echo e($user->name); ?></p>
                                    <?php if($user->is_host): ?>
                                        <p class="text-xs text-blue-600 font-semibold">👑 Host</p>
                                    <?php else: ?>
                                        <p class="text-xs text-slate-600">👤 Guest</p>
                                    <?php endif; ?>
                                </div>
                                <a href="/profile" class="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">👤 Profil</a>
                                <?php if(!$user->is_host): ?>
                                    <a href="#" class="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">📱 Jadilah Host</a>
                                <?php endif; ?>
                                <form method="POST" action="<?php echo e(route('logout')); ?>" class="block">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="w-full text-left px-4 py-2 text-sm text-rose-600 hover:bg-rose-50">🚪 Logout</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="/login" class="px-4 py-2 rounded-lg bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700">Login</a>
                <?php endif; ?>
            </div>

            <!-- Mobile Menu Button -->
            <button class="md:hidden text-slate-600" id="mobileMenuBtn">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
            </button>
        </div>

        <!-- Mobile Menu -->
        <div id="mobileMenu" class="hidden md:hidden mt-4 space-y-2 border-t border-slate-100 pt-4">
            <?php if(auth()->guard()->check()): ?>
                <?php ($user = Auth::user()); ?>
                <?php if(!$user->is_host): ?>
                    <a href="/" class="block px-4 py-2 text-slate-600 hover:bg-slate-50 rounded">Cari Station</a>
                    <a href="/my-bookings" class="block px-4 py-2 text-slate-600 hover:bg-slate-50 rounded">Booking Saya</a>
                <?php else: ?>
                    <a href="/host/dashboard" class="block px-4 py-2 text-slate-600 hover:bg-slate-50 rounded">Dashboard</a>
                    <a href="/host/create" class="block px-4 py-2 text-slate-600 hover:bg-slate-50 rounded">Tambah Station</a>
                <?php endif; ?>
                <a href="/profile" class="block px-4 py-2 text-slate-600 hover:bg-slate-50 rounded">Profil</a>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="w-full text-left px-4 py-2 text-rose-600 hover:bg-rose-50 rounded">Logout</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</header>

<script>
    document.getElementById('mobileMenuBtn')?.addEventListener('click', () => {
        document.getElementById('mobileMenu').classList.toggle('hidden');
    });
</script>
<?php /**PATH C:\laragon\www\voltshare\resources\views/components/navbar.blade.php ENDPATH**/ ?>