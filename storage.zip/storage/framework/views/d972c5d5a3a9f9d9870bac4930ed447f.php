

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto px-4 py-8">
    <div class="bg-white border border-slate-200 rounded-xl shadow-sm p-6 space-y-4">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-semibold text-slate-900">Tambah Station</h1>
                <p class="text-sm text-slate-500">Masukkan detail station Anda</p>
            </div>
            <a href="/host/dashboard" class="text-sm text-slate-600 hover:text-slate-900">Kembali</a>
        </div>

        <form action="/host/store" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="space-y-1">
                    <label class="text-sm font-semibold text-slate-700">Nama Station</label>
                    <input name="name" value="<?php echo e(old('name')); ?>" class="w-full rounded-lg border border-slate-200 px-3 py-2 focus:border-blue-500 focus:ring-blue-500" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-xs text-rose-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="space-y-1">
                    <label class="text-sm font-semibold text-slate-700">Harga per Jam (IDR)</label>
                    <input type="number" name="price_per_hour" step="0.01" value="<?php echo e(old('price_per_hour')); ?>" class="w-full rounded-lg border border-slate-200 px-3 py-2 focus:border-blue-500 focus:ring-blue-500" required>
                    <?php $__errorArgs = ['price_per_hour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-xs text-rose-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="space-y-1">
                <label class="text-sm font-semibold text-slate-700">Alamat</label>
                <input name="address" value="<?php echo e(old('address')); ?>" class="w-full rounded-lg border border-slate-200 px-3 py-2 focus:border-blue-500 focus:ring-blue-500">
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-xs text-rose-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="space-y-1">
                <label class="text-sm font-semibold text-slate-700">Google Maps Link (opsional)</label>
                <input name="google_maps_link" value="<?php echo e(old('google_maps_link')); ?>" class="w-full rounded-lg border border-slate-200 px-3 py-2 focus:border-blue-500 focus:ring-blue-500" placeholder="https://maps.google.com/...">
                <p class="text-xs text-slate-500">Jika lat/long kosong, sistem akan mencoba ambil koordinat dari link (@lat,lng).</p>
                <?php $__errorArgs = ['google_maps_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-xs text-rose-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="space-y-1">
                    <label class="text-sm font-semibold text-slate-700">Latitude</label>
                    <input name="latitude" value="<?php echo e(old('latitude')); ?>" class="w-full rounded-lg border border-slate-200 px-3 py-2 focus:border-blue-500 focus:ring-blue-500" placeholder="-6.1750">
                    <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-xs text-rose-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="space-y-1">
                    <label class="text-sm font-semibold text-slate-700">Longitude</label>
                    <input name="longitude" value="<?php echo e(old('longitude')); ?>" class="w-full rounded-lg border border-slate-200 px-3 py-2 focus:border-blue-500 focus:ring-blue-500" placeholder="106.8270">
                    <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-xs text-rose-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="pt-2">
                <button type="submit" class="w-full inline-flex justify-center px-4 py-2 rounded-lg bg-blue-600 text-white font-semibold hover:bg-blue-700">Simpan Station</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\voltshare\resources\views/host/create.blade.php ENDPATH**/ ?>